from flask import Flask, render_template, request

app = Flask(__name__)

lista = []

@app.route('/criar', methods=['GET', 'POST'])
def criar():
    if request.method == 'POST':
        # Obter os dados do formulário
        nome = request.form['nome']
        data_nascimento = request.form['data_nascimento']
        cor_favorita = request.form['cor_favorita']
        email = request.form['email']
        sexo = request.form['sexo']

        # Adicionar os dados à lista
        lista.append({
            'Nome': nome,
            'Data de Nascimento': data_nascimento,
            'Cor Favorita': cor_favorita,
            'Email': email,
            'Sexo': sexo
        })

        return '<script>alert("Dados enviados com sucesso!"); window.location="/criar";</script>'
    return render_template('index.html')

@app.route('/listar')
def listar():
    return render_template('listar.html', dados=lista)

app.run()